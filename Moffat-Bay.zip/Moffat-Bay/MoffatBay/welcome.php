<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require 'navbar.php'; ?>

    <main>
        <h2>Welcome!</h2>
        <p>You have successfully registered and are now logged in.</p>
        <a href="index.php">Go to Home</a>
    </main>
</body>
</html>
