<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moffat Bay</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require 'navbar.php'; ?>

    <main>
	
       
		<div class="inline-container2">
		<img src="Marina.jpg" alt="Company Logo" class="image2">
		<div class="text2">
		 <h2>About Us</h2>
        <p>Moffat Bay Resort and Marina, nestled in the picturesque San Juan Islands, 
		is a newly developed destination that offers a perfect blend of luxury and 
		natural beauty. Our story began just six months ago when the San Juan 
		Islands First Nations Development Committee approved the construction 
		of our resort and marina on the stunning Joviedsa Island.</p>
		</div>
        </div>
		
		<div class="inline-container">
		<img src="Marina2.jpg" alt="Company Logo" class="image">
		<div class="text">
        <h2>Pricing</h2>
        <p>The crown jewel of our development is our cutting-edge marina, 
		which caters to a variety of boat sizes:</p>
		<p>26 ft slips ($50.00 per day)</p>
		<p>40 ft slips ($55.00 per day)</p>
		<p>50 ft slips ($60.00 per day)</p>
		<p>We ensure that each vessel is accommodated in a slip that perfectly 
		fits its length, prioritizing both safety and convenience for our guests.</p>
		</div>
		</div>
    </main>
	
