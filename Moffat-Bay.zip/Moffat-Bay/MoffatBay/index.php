<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moffat Bay</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <?php require 'navbar.php'; ?>

    <main>
        <div class="image-container">
            <img src="boat.jpg" alt="Boat" class="main-image">
            <div class="overlay-text">Welcome To The Moffat Bay Island Marina</div>
        </div>

        <div class="parent-container">
            <div class="child-container">
                <h3>Events</h3>
                <p>Fishing Tournament April 3rd 2025</p>
            </div>
            <div class="child-container">
                <h3>About Us</h3>
                <p>Escape & Explore Our Large Bay</p>
                <button class="abBtn">
                    <a href="aboutUs.php">
                        <span>Click Here To</span>
                        <span>Learn More</span>
                    </a>
                </button>
            </div>
        </div>
    </main>



</body>
</html>
