<header>
    <img src="logo.png" alt="Company Logo" class="logo">
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="aboutUs.php">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
            <li><a href="#">Slip Reservation</a></li>
            <li><a href="#">Reservation Lookup</a></li>
            <li><a href="#">Wait list</a></li>

            <?php if (!isset($_SESSION['loggedin'])): ?>
                <!-- Show the Registration and Login links when user is NOT logged in -->
                <li><a href="registration.php">Registration</a></li>
                <li><a href="login.php">Login</a></li>
            <?php else: ?>
                <!-- Show the email and Logout link when user is logged in -->
                <li><span>Logged in as <?php echo htmlspecialchars($_SESSION['email']); ?></span></li>
                <li><a href="logout.php">Logout</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
