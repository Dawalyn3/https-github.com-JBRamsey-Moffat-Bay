<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moffat Bay</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require 'navbar.php'; ?>

    <main>
	<div class="inline-container3">
		<img src="Login_Boat.jpg" alt="Company Logo" class="image3">
		<h2 class="text4">Welcome back <?php echo htmlspecialchars($_SESSION['email'])?>!</h2>
	</div>
</body>
    </main>
</html>