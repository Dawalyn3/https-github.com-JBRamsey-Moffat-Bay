<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moffat Bay</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require 'navbar.php'; ?>

    <main>
	<div class="inline-container3">
		<img src="Login_Boat.jpg" alt="Company Logo" class="image3">
   		<form method="POST" action="signin.php">
        		<h2 class="text3">Log In</h2>
        		<input type="text" name="email" placeholder="Email" required><br>
        		<input type="password" name="password" placeholder="Password" required><br>
        		<input type="submit" value="Sign In">
        		<p>Don't have an account? <a href="Registration.php">Sign Up</a></p>
    		</form>
	</div>
</body>
    </main>
</html>