<?php
	session_start();
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	include 'db.php';
	$message = '';

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		// Retrieve form data
    		$email = $_POST['email'];
    		$password = $_POST['password'];
		
		$stmt = $conn->prepare("SELECT customer_id, password FROM Customer WHERE email_address = ?");
		$stmt->bind_param("s", $email);
		$stmt->execute();
		$stmt->store_result();
		$stmt->bind_result($id, $password_hash);
		$stmt->fetch();

		//to test using the users already in the database, use if ($password == $password_hash) instead since those are not hashed
		if (password_verify($password, $password_hash)) {
    			// Password is correct
			$_SESSION['loggedin'] = true;
			$_SESSION['email'] = $email;
			header("Location: login_Welcome.php");
    			exit();
		} 
		else {
    			// Password is incorrect
    			echo "Invalid username or password.";
		}

		$stmt->close();
		$conn->close();
	}
?>
