<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db.php';
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST['email'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $phoneNumber = $_POST['phoneNumber'];
    $boatName = $_POST['boatName'];
    $boatLength = $_POST['boatLength'];
    $password = $_POST['password'];

    if (isset($_POST['confirm'])) {
        // Check if email already exists
        $sql = "SELECT * FROM Customer WHERE email_address = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $message = "Error: Email is already registered.";
            $stmt->close();
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $conn->begin_transaction();

            try {
                $sql = "INSERT INTO Customer (email_address, first_name, last_name, phone_number, password) VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssss", $email, $firstName, $lastName, $phoneNumber, $hashedPassword);
                $stmt->execute();

                $customerId = $conn->insert_id;
                $stmt->close();

                $sql = "INSERT INTO Boat (customer_id, boat_name, boat_length) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("isi", $customerId, $boatName, $boatLength);
                $stmt->execute();
                $stmt->close();

                $conn->commit();
                
                $_SESSION['loggedin'] = true;
                $_SESSION['email'] = $email;
                header("Location: welcome.php");
                exit();
            } catch (Exception $e) {
                $conn->rollback();
                $message = "Error: " . $e->getMessage();
            }

            $conn->close();
        }
    } elseif (isset($_POST['cancel'])) {
        $message = "Registration cancelled.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php require 'navbar.php'; ?>

    <main>
    <form method="POST" action="signup.php">
        <h2>Confirm Your Details</h2>
        <?php if ($message) echo "<p>$message</p>"; ?>

        <?php if (!isset($_POST['confirm'])): ?>
        <p>Email: <?php echo htmlspecialchars($_POST['email']); ?></p>
        <p>First Name: <?php echo htmlspecialchars($_POST['firstName']); ?></p>
        <p>Last Name: <?php echo htmlspecialchars($_POST['lastName']); ?></p>
        <p>Phone Number: <?php echo htmlspecialchars($_POST['phoneNumber']); ?></p>
        <p>Boat Name: <?php echo htmlspecialchars($_POST['boatName']); ?></p>
        <p>Boat Length: <?php echo htmlspecialchars($_POST['boatLength']); ?></p>

        <input type="hidden" name="email" value="<?php echo htmlspecialchars($_POST['email']); ?>">
        <input type="hidden" name="firstName" value="<?php echo htmlspecialchars($_POST['firstName']); ?>">
        <input type="hidden" name="lastName" value="<?php echo htmlspecialchars($_POST['lastName']); ?>">
        <input type="hidden" name="phoneNumber" value="<?php echo htmlspecialchars($_POST['phoneNumber']); ?>">
        <input type="hidden" name="boatName" value="<?php echo htmlspecialchars($_POST['boatName']); ?>">
        <input type="hidden" name="boatLength" value="<?php echo htmlspecialchars($_POST['boatLength']); ?>">
        <input type="hidden" name="password" value="<?php echo htmlspecialchars($_POST['password']); ?>">

        <input type="submit" name="confirm" value="Confirm">
        <input type="submit" name="cancel" value="Cancel">
        <?php else: ?>
        <p>You have already confirmed your registration.</p>
        <?php endif; ?>
    </form>
    </main>
</body>
</html>
